$(document).ready(function () {
    var books = [];
    var currentIndex = 0;
    var booksPerPage = 5;

    function loadBooks() {
        $.ajax({
            url: '//http/books.json',
            method: 'GET',
            dataType: 'json',
            beforeSend: function () {
                // Show loading indicator (e.g., using jQuery UI progress bar)
                $('#book-list').html('<p>Loading books...</p>');
            },
            success: function (data) {
                books = data;
                displayBooks();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Handle errors (e.g., display error message)
                console.error("Error loading books:", textStatus, errorThrown);
                $('#book-list').html('<p>Error loading books. Please try again.</p>');
            }
        });
    }

    function displayBooks() {
        var endIndex = currentIndex + booksPerPage;
        var booksToDisplay = books.slice(currentIndex, endIndex);

        $('#book-list').empty(); // Clear previous content

        booksToDisplay.forEach(function (book) {
            $('#book-list').append(`
        <li>
          <img src="${book.image}" alt="${book.title}">
          <h3>${book.title}</h3>
          <p>${book.author}</p>
          <p>${book.description}</p>
        </li>
      `);
        });

        currentIndex = endIndex;

        // Update or disable 'load-more' button based on available books
        if (endIndex >= books.length) {
            $('#load-more').disable(); // Disable load-more button (example)
        } else {
            $('#load-more').enable(); // Enable load-more button (example)
        }
    }

    $('#load-more').on('click', function () {
        displayBooks();
    });

    loadBooks();
});
